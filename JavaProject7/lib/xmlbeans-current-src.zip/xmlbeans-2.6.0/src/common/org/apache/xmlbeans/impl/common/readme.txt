There are isolated files in this directory taken from the Apache
Xerces-J 2.0 project

It contains very minor modifications including a change in namespace.

